#컴활2급 합격 계산기
#각 과목의 점수 입력
Computer = int(input("컴퓨터 일반과목 성적을 입력하세요"))
Spreadsheet = int(input("스프레드시트 일반과목 성적을 입력하세요"))

#점수들의 합을더해 Total score를 구함
Totalscore = Computer + Spreadsheet
averagescore = Totalscore //2
#Total score가 평균 60이상을 경우
if averagescore >= 60:
    print("당신의 평균 점수는",averagescore,"축하합니다 합격입니다.")
#Total score가 평균 50~59여서 아쉽게 탈락했을경우
elif averagescore >= 50 and Totalscore//2 < 60:
    print("당신의 평균 점수는",averagescore,"아쉽게 탈락입니다.")
#평균 점수가 50점 아래로 탈락했을 경우
else:
    print("당신의 평균 점수는",averagescore ,"탈락입니다")
