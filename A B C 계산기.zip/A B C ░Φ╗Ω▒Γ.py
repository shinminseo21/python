#A, B, C등급 계산기
subject = input("과목이 예체능인지 인문계인지 입력해주세요.")
score = int(input("점수를 입력해주세요."))

if subject == "예체능":
    if score >= 80:
        print("A")
    elif score >= 60:
        print("B")

    else:
        print(c)
else:
    pass
if subject == "인문":
    if score >= 90:
        print("A")
    if score >= 80:
        print("B")
    if score >= 70:
        print("C")
    if score >= 60:
        print("D")
    else:
        print("E")
